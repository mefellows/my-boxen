#!/bin/bash

# iPhoto photos
rsync -avzu -e "ssh -l onegeekd" -C -c  \
 --exclude=AlbumData.xml \
 --exclude=Auto \
 --exclude=Contents \
 --exclude=Data \
 --exclude=Library.data \
 --exclude=Library.iPhoto \
 --exclude=Library6.iPhoto \
 --exclude=ThemeCache \
 --exclude=Thumb32Segment.data \
 --exclude=Thumb64Segment.data \
 --exclude=ThumbJPGSegment.data \
 --exclude=iPhoto.ipspot \
 --exclude=iPhotoLock.data \
 --exclude=iPod \
 --exclude=*.ithmb \
 onegeekd@onegeek.com.au:repository/personal/photos/iPhotoLibrary/ /Users/mfellows/Pictures/iPhoto\ Library/ 
