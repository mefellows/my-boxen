#!/bin/bash
SERVERS=(prd-rtl-105, prt-rtl-106, prd-rtl-107, prd-rtl-108 )
FILENAME=cocoon-log-2010_04_2

ssh mfellows@bss.us.mit
cd /var/prod/tomcat5

for server in ${SERVERS[@]}
do
	ls -larth $server
done
