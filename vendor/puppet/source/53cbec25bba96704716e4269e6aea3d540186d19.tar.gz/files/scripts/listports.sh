#!/bin/sh
lsof -i -P | grep -i "listen"
