#!/usr/local/php-5.3.6/bin/php
<?php
	error_reporting(E_ALL);
	
	echo "<h2>TCP/IP Connection</h2>\n";
	
	/* Get the port for the WWW service. */
	$service_port = 8380;//getservbyname('www', 'tcp');
	
	/* Get the IP address for the target host. */
	$address = gethostbyname('jboss-prd-rsp.mit');
	
	/* Create a TCP/IP socket. */
	$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
	if ($socket === false) {
	    echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
	} else {
	    echo "OK.\n";
	}
	
	echo "Attempting to connect to '$address' on port '$service_port'...";
	$result = socket_connect($socket, $address, $service_port);
	if ($result === false) {
	    echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
	} else {
	    echo "OK.\n";
	}
	
	

$in .='POST /OrderManagement/services/CatalogService HTTP/1.1' . "\r\n";
$in .='Content-Type: text/xml;charset=UTF-8' . "\r\n";
$in .='SOAPAction: ""' . "\r\n";
$in .='User-Agent: Jakarta Commons-HttpClient/3.1' . "\r\n";
$in .='Content-Length: 512' . "\r\n";
$in .='Authorization: Basic d2ViYmllczp3ZWJiaWVz' . "\r\n";
$in .='Host: int-jbo-101:8380' . "\r\n";
$in .="\r\n";
$in .='<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns1="http://service.ordermanagement.melbourneit.com"><SOAP-ENV:Body><ns1:searchForProducts><ns1:in0><ns1:entry><ns1:key>channel</ns1:key><ns1:value>RETAIL</ns1:value></ns1:entry><ns1:entry><ns1:key>currency</ns1:key><ns1:value>USD</ns1:value></ns1:entry></ns1:in0><ns1:in1><ns1:string>DOMAINSERVICE</ns1:string></ns1:in1><ns1:in2><ns1:string>New</ns1:string></ns1:in2></ns1:searchForProducts></SOAP-ENV:Body></SOAP-ENV:Envelope>';


/*
	$in = "HEAD / HTTP/1.1\r\n";
	$in .= "Host: jboss-prd-rsp.mit\r\n";
	$in .= 'SOAPAction: "http://service.ordermanagement.melbourneit.com"'
	$in .= "Host: jboss-prd-rsp.mit\r\n";
	$in .= "Connection: Close\r\n\r\n";
	$out = '';
*/	

	while(true) {
		echo "Sending HTTP HEAD request...";
		socket_write($socket, $in, strlen($in));
		echo "OK.\n";
		
		echo "Reading response:\n\n";
		while ($out = socket_read($socket, 2048)) {
		    echo $out;
		}
	}
	
	echo "Closing socket...";
	socket_close($socket);
	echo "OK.\n\n";
?>
