#!/usr/local/php-5.3.8/bin/php
<?php  
	set_include_path(get_include_path().PATH_SEPARATOR.'/var/www/new.retail.melbourneit.com.au/MIT/library');
	
	require_once 'Zend/Loader/Autoloader.php';
	$loader = Zend_Loader_Autoloader::getInstance();
	$loader->registerNamespace(array('MIT', 'Reseller'));
	
	//$om = new MIT_Om('webbies', 'webbies', 'http://jboss-prd-rsp.mit:8380');
	
	error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);	
$channel = "RETAIL";
    $currencyList = array('AUD' , 'USD');
    $operationList = array("New", "RenewDomain", "TransferDomain");
    $categoryList = array('DOMAINNAME' , 'DOMAINSERVICE' , 'PLAN' , 'DNPACK' , 'WEBSITE' , 'SEM' , 
                                        'SUNRISEA' , 'SUNRISEB' , 'LANDRUSH' , 'GENERALAVAIL');
$index = null;
$response = null;
    
	$params = array('login' => 'webbies' , 'password' => 'webbies' , 'user_agent' => 'MIT/SOAP' , 'connection_timeout' => 600);
	$client = new SoapClient("http://jboss-prd-rsp.mit:8380/OrderManagement/services/CatalogService?wsdl", $params);	
	//$handle = fopen("/tmp/test-socket-soap-tmp.txt", "a+");
$cache = Zend_Cache::factory('Core', 'File', array('automatic_serialization' => true , ' lifetime' => 3600), array('cache_dir' => '/var/tmp/cache2'));
            try {
                //$client = new MIT_Om_Soap_Catalog($om);
                
                foreach ($currencyList as $currency) { // loop each currency
                    foreach ($operationList as $operation) { // loop each operation
                        foreach ($categoryList as $category) { // loop each category
                        	// Attempt up to WEB_SERVICE_CALL_MAX_ATTEMPTS calls to fetch the product data
                        	$attempts = 0;
                        	
                        	// Check if current search has been performed by cache key lookup
                        	// if it exists, don't call the web service again
                        	$webServiceCacheKey = 'ws_RETAIL' . $currency . $category . $operation;
                        	$response = $cache->load($webServiceCacheKey);
                        	
                        	if (!$response) {
                        		                        	
	                            // Perform the product search and cache the result
	                            // Try up to WEB_SERVICE_CALL_MAX_ATTEMPTS times to get a result else fail
	                            do {
		                            try {  
		                            	$response = null;                                             
						echo "Calling web service with params: RETAIL $currency $category $operation. Attempt: $attempt";
						$response = $client->searchForProducts(array('in0' => array(array('key' => 'channel' , 'value' => "RETAIL") , array('key' => 'currency' , 'value' => $currency)) , 'in1' => array($category) , 'in2' => array($operation)));
$response = $response->out;
					    } catch (Zend_Exception $e) {
						    // log exception
						   echo "Zend Exception : ";
						var_dump($e->getMessage());
					    } catch (SoapFault $e) {
						    // log soap fault
						   echo "SoapFault : ";
						var_dump($e);
					    }
				    } while ($attempts < 3 && $response == null);

				    if ($attempts = 3 && $response == null) {


					    throw new Zend_Exception("Product catalog could not be refreshed, reached max tries (3)");
				    }

				    // Make a note that this web service has been called
				    $cache->save($response, $webServiceCacheKey, array(), null);
				}
				// $response contains product data
				if (isset($response->{'ProductVO'}) && ! empty($response->{'ProductVO'})) {
echo "product response exists";

					$productVOs = (array) $response->{'ProductVO'};
					foreach ($productVOs as $productVO) {

						// save product data to cache                                    
						$cacheId = 'PRODUCT_CATALOG_' . $productVO->catalogId;

						if (! $product = $cache->load($cacheId)) { // cache miss

							// create new MIT_Om_Product object from $productVO
							$product = new MIT_Om_Product((array) $productVO);
						} else {
							// add new MIT_Om_Product_Price object to existing product
							$product->addPrice(new MIT_Om_Product_Price((array) $productVO));
						}

						$cache->save($product, $cacheId, array(), null);

						// save catalog index data


						if (! isset($index['name'][$product->getName()]) || ! in_array($productVO->catalogId, $index['name'][$product->getName()])) {
							$index['name'][$product->getName()][] = $productVO->catalogId;
						}

						if (! isset($index['description'][$product->getDescription()]) || ! in_array($productVO->catalogId, $index['description'][$product->getDescription()])) {
							$index['description'][$product->getDescription()][] = $productVO->catalogId;
						}

						if (! isset($index['period'][$product->getPeriod()]) || ! in_array($productVO->catalogId, $index['period'][$product->getPeriod()])) {
							$index['period'][$product->getPeriod()][] = $productVO->catalogId;
						}

						if (! isset($index['period_unit'][$product->getPeriodUnit()]) || ! in_array($productVO->catalogId, $index['period_unit'][$product->getPeriodUnit()])) {
							$index['period_unit'][$product->getPeriodUnit()][] = $productVO->catalogId;
						}

						foreach ($product->getCategories() as $category) {
							if (isset($index['category'][$category]) && in_array($productVO->catalogId, $index['category'][$category])) {
								continue;
							}
							$index['category'][$category][] = $productVO->catalogId;
						}

					}
				}

				// Perform the product search                                                   
echo "Response: ";
				var_dump($response);
                        }
                    }
                }
            
            } catch (SoapFault $sf) {
                throw $sf;
            }
$cache->save($index, 'CACHE_ID_PRODUCT_CATALOG_INDEX', array(), null);
        echo "Called all web services!";
var_dump($index);
?>
