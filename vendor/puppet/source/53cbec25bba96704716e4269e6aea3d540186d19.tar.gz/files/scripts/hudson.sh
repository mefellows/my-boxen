#!/bin/sh
PID="./.hudson/hudson.pid"

start_hudson ()
{
  echo "Starting Hudson..."
  if [ -f "$PID" ]; then
    echo "Hudson already running, (PID file $PID exists)"
  else
    java -jar hudson.war --httpPort=8007 &
    touch $PID
  fi
}

stop_hudson ()
{

  ps -deaf | grep java  | grep hud | egrep -v grep | awk -F" " '{print $2}' | xargs kill -9
  if [ -f "$PID" ]; then
    rm $PID
  fi
}

help ()
{
  echo "Usage"
  echo "        ./hudson.sh stop"
  echo "        ./hudson.sh stop"
  
}

if [ "$1" = "start" ]; then
  start_hudson
elif [ "$1" = "stop" ]; then
    stop_hudson
else
    help
fi
