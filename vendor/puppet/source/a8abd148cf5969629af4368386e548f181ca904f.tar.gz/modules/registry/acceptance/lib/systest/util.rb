require 'pathname'
require Pathname.new(__FILE__).dirname
module Systest::Util
end
