Note that some history for the .spec files here is available in https://hg.mozilla.org/build/rpm-sources
