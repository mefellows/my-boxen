

select * from customer where institution ="Cement Australia (Queensland) Pty Limited"
select * from customer where institution ="Cement Australia (Queensland) Pty Ltd"
select * from customer where institution ="Cement Australia Holdings Pty Ltd"
select * from customer where institution ="Cement Australia Packaged Products Pty Limited"
select * from customer where institution ="Cement Australia Pty Limited"
select * from customer where institution ="Cement Australia Pty Ltd"