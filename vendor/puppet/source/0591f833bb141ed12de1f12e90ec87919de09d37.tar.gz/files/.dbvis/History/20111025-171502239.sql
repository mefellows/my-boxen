@export on;
@export set filename="/Users/sgeary/Desktop/results.csv" appendfile="true" format="CSV";

select 'ZERO CARD ; ZEROCARD' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Bank of Western Australia%');
select 'ZERO CHANGE BATTERY' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Century Yuasa Batteries%');
select 'ZERO TORQUE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Michell Meat%');

