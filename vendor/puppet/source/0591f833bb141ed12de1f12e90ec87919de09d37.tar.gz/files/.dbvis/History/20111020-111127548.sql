select * from MIT_SPIN.CUSTOMER where trim(institution) = 'BUNDABERG BREWED DRINKS';
select * from MIT_SPIN.CUSTOMER where institution like '%BUNDABERG BREWED DRINKS%';