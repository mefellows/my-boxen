#!/usr/local/php-5.3.8/bin/php
<?php  
	set_include_path(get_include_path().PATH_SEPARATOR.'/var/www/new.retail.melbourneit.com.au/MIT/library');
	
	require_once 'Zend/Loader/Autoloader.php';
	$loader = Zend_Loader_Autoloader::getInstance();
	$loader->registerNamespace(array('MIT', 'Reseller'));
	
	//$om = new MIT_Om('webbies', 'webbies', 'http://jboss-prd-rsp.mit:8380');
	
	error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);	
	$params = array('login' => 'webbies' , 'password' => 'webbies' , 'user_agent' => 'MIT/SOAP' , 'connection_timeout' => 600);
	$client = new SoapClient("http://jboss-prd-rsp.mit:8380/OrderManagement/services/CatalogService?wsdl", $params);	

        $myAccount = "RETAILTEST2010AU";
        $domainName = "testbbtest1234.com";
        $statuses = array("COMPLETED", "FAILED");        
        $params = array('login' => 'webbies' , 'password' => 'webbies' , 'user_agent' => 'MIT/SOAP' , 'connection_timeout' => 600);        
        $client = new SoapClient("http://jboss-prd-rsp.mit:8580/DNSManagement/services/DNSManagement?wsdl", $params);
        
        
$wsResponse = $client->getDNSResourceDetails(array('in0' => $myAccount , 'in1' => $domainName , 'in2' => $statuses));
var_dump($wsResponse);

        $wsResponse = (object) $wsResponse->out;
        $result = $wsResponse->result;
var_dump($result);
        $error = "";        
        
        if ($result == MIT_Om_Constants::RESULT_SUCCESS) {
echo "success";
            $resourceRecords = $wsResponse->resourceRecords;
            $resourceRecordsVO = $resourceRecords->ResourceRecordVO;
            foreach ($resourceRecordsVO as $vo) {
                if ($vo->type == MIT_Dns_Constants::RR_ATYPE || $vo->type == MIT_Dns_Constants::RR_CNAMETYPE || $vo->type == MIT_Dns_Constants::RR_AAAATYPE) {
                    $rr = MIT_Dns_DNSUtil::setRRArray($vo);
                    array_push($rrACname, $rr);
                } else if ($vo->type == MIT_Dns_Constants::RR_MXTYPE) {
                    $rr = MIT_Dns_DNSUtil::setRRArray($vo);
                    array_push($rrMX, $rr);
                } else if ($vo->type == MIT_Dns_Constants::RR_TXTTYPE) {
                    $rr = MIT_Dns_DNSUtil::setRRArray($vo);
                    array_push($rrTXT, $rr);
                } else if ($vo->type == MIT_Dns_Constants::RR_NSTYPE) {
                    $rr = MIT_Dns_DNSUtil::setRRArray($vo);
                    array_push($rrNS, $rr);
                }
            }
        } else {
echo "Error: $error";
            $error = $wsResponse->error;
            $errorCode = substr($wsResponse->error, 1, strpos($wsResponse->error, ":") - 1);
        }
        
        MIT_Dns_DNSUtil::getInfoLogGetRRResponseString(MIT_Dns_Constants::GET_DNS_RESOURCES, $result, $error, $rrACname, $rrMX, $rrNS);

?>
