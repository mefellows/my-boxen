#!/usr/local/php-5.3.6/bin/php
<?php
error_reporting(E_ALL);

for ($i=0;$i<30;$i++) {
	try {
		$client = new SoapClient("http://soaptest.parasoft.com/calculator.wsdl");
		$response = $client->add(array("x" => 5, "y" => 15));
sleep(60);
		var_dump($response);
	} catch (SoapFault $e) {
		echo "SoapFault: " . var_dump($e);
	}
}
?>
