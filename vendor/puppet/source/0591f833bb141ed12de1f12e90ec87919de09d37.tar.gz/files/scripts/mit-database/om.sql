select unique(sourceip) from MIT_MITEC2.sales_order where creation_date > to_date('1-jan-2011')

select sourceip from MIT_MITEC2.sales_order where creation_date > to_date('1-jan-2011') and order_status_id = 110

select sourceip from MIT_MITEC2.sales_order where creation_date > "2011-01-01 00:00:00" and order_status_id = 110

select * from MIT_MITEC2.sales_order where creation_date is not null

select * from MIT_MITEC2.sales_order so, MIT_MITEC2.package p where p.order_id = so.sales_order_id and sourceip in ('67.205.112.74','67.205.89.142','96.44.165.100')

select * from MIT_MITEC2.sales_order so, MIT_MITEC2.package p, MIT_MITEC2.order_line ol where ol.package_id = p.package_id and p.order_id = so.sales_order_id and sourceip in ('67.205.112.74','67.205.89.142','96.44.165.100')