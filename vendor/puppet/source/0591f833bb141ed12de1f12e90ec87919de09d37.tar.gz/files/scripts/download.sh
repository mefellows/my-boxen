#!/bin/bash
FILES=( http://mb11.legalsounds.com/download/40dd86eb2844e29d91cdd8831b51a902/08_-_the_approaching_curve_-_the_sufferer_and_the_witness.mp3 
http://mb11.legalsounds.com/download/40dd86eb2844e29d42d91e06495dab62/02_-_injection_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29dd276df2a868d902d/07_-_drones_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29d2c3270bc1324f2ec/03_-_ready_to_fall_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29d244f4ca78148635e/11_-_roadside_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29ddf37e73e2e41e597/12_-_the_good_left_undone_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/806ea2678579f842244f4ca78148635e/13_-_survive_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/806ea2678579f842a7f60351aa8a80d1/05_-_under_the_knife_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29d3a8a9d93618fd8dd/01_-_chamber_the_cartridge_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29d758781d074f7a183/09_-_worth_dying_for_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29da7f60351aa8a80d1/04_-_bricks_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/806ea2678579f842758781d074f7a183/06_-_prayer_for_a_refugee_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/46553d169bd49c422c3270bc1324f2ec/14_-_but_tonight_we_dance_%28bonus_track%29_-_the_sufferer_and_the_witness.mp3
http://mb11.legalsounds.com/download/40dd86eb2844e29d42fb1398c1587113/10_-_behind_closed_doors_-_the_sufferer_and_the_witness.mp3)

for song in ${FILES[@]}
do
	wget $song
done
