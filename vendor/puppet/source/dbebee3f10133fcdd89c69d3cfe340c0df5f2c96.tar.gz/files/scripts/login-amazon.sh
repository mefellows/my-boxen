#!/bin/sh

ssh -i /Users/mattfellows/.ssh/mfellows-amazon-ec2.pem ubuntu@ec2-50-18-132-103.us-west-1.compute.amazonaws.com
