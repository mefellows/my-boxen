#!/usr/local/php-5.3.8/bin/php
<?php
        error_reporting(E_ALL);

        /* Get the port for the WWW service. */
        $service_port = 8580;
        
        /* Get the IP address for the target host. */
        $address = gethostbyname('jboss-prd-rsp.mit');
        

        /* Create a TCP/IP socket. */

        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if ($socket === false) {
            echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
        } else {
            echo "OK.\n";
        }
        
        echo "Attempting to connect to '$address' on port '$service_port'...";
        $result = socket_connect($socket, $address, $service_port);
        if ($result === false) {
            echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
        } else {
            echo "OK.\n";
        }

        $in .='POST /DNSManagement/services/DNSManagement HTTP/1.1' . "\r\n";
        $in .='Content-Type: text/xml;charset=UTF-8' . "\r\n";
        $in .='SOAPAction: ""' . "\r\n";
        $in .='User-Agent: Jakarta Commons-HttpClient/3.1' . "\r\n";
        $in .='Content-Length: 512' . "\r\n";
        $in .='Authorization: Basic d2ViYmllczp3ZWJiaWVz' . "\r\n";
        $in .='Host: jboss-prd-rsp.mit:8580' . "\r\n";
        $in .="\r\n";
        $in .='<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.dns.melbourneit.com"> <soapenv:Header/> <soapenv:Body> <ser:getDNSResourceDetails> <ser:in0>RETAILTEST2010AU</ser:in0> <ser:in1>testbbtest1234.com</ser:in1> <ser:in2> <!--Zero or more repetitions:--> <ser:string>COMPLETED, FAILED</ser:string> </ser:in2> </ser:getDNSResourceDetails> </soapenv:Body> </soapenv:Envelope>';

        echo "Sending HTTP HEAD request...";
        socket_write($socket, $in, strlen($in));
        echo "OK.\n";
        
        echo "Reading response:\n\n";
        while ($out = socket_read($socket, 2048)) {
            echo $out;
        }
        
        if ($out === false) {
                echo "Error while reading response:";
                echo socket_strerror(socket_last_error($socket));
                socket_close($socket);
                exit;
        }

        
        echo "Closing socket...";
        socket_close($socket);
        echo "OK.\n\n";

        
?>
