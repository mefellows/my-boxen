#!/usr/local/php-5.3.6/bin/php
<?php
        set_include_path(get_include_path().PATH_SEPARATOR.'/var/www/new.retail.melbourneit.com.au/MIT/library');

        //require_once 'Zend/Loader/Autoloader.php';
        //$loader = Zend_Loader_Autoloader::getInstance();
        //$loader->registerNamespace(array('MIT', 'Reseller'));

        //$om = new MIT_Om('webbies', 'webbies', 'http://jboss-prd-rsp.mit:8380');

        error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
$channel = "RETAIL";
    $currencyList = array('AUD' , 'USD');
    $operationList = array("New", "RenewDomain", "TransferDomain");
    $categoryList = array('DOMAINNAME' , 'DOMAINSERVICE' , 'PLAN' , 'DNPACK' , 'WEBSITE' , 'SEM' ,
                                        'SUNRISEA' , 'SUNRISEB' , 'LANDRUSH' , 'GENERALAVAIL');

        $params = array('login' => 'webbies' , 'password' => 'webbies' , 'user_agent' => 'MIT/SOAP' , 'connection_timeout' => 600);
        //$client = new SoapClient("http://jboss-ext-rsp.mit:8380/OrderManagement/services/CatalogService?wsdl", $params);
        $client = new SoapClient("http://www.webservicex.net/BibleWebservice.asmx?WSDL");
var_dump($client->__getFunctions());
var_dump($client->__getTypes());

            try {

                foreach ($currencyList as $currency) { // loop each currency
                    foreach ($operationList as $operation) { // loop each operation
                        foreach ($categoryList as $category) { // loop each category
                            // Perform the product search
                            //$response = $client->searchForProductsService($channel, $currency, array($category), array($operation));
                            //$response = $client->searchForProducts(array('in0' => array(array('key' => 'channel' , 'value' => "RETAIL") , array('key' => 'currency' , 'value' => 'AUD')) , 'in1' => array("SUNRISEA") , 'in2' => array("New")));
                            //$response = $client->searchForProducts(array('in0' => array(array('key' => 'channel' , 'value' => "RETAIL") , array('key' => 'currency' , 'value' => $currency)) , 'in1' => array($category) , 'in2' => array($operation)));

                                //$response = $client->GetBibleWordsByKeyWord('in0' => array('god'));
                                $response = $client->GetBibleWordsByKeyWord(array('BibleWords' => 'god'));
var_dump($response);
echo "****Waiting 20 s to simulate write to file duration***";
// Simulate file system write
sleep(20);
                        }
                    }
                }

            } catch (SoapFault $sf) {
                throw $sf;
            }
        echo "Called all web services!";
?>
