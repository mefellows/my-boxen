select * from MIT_SPIN.CUSTOMER, MIT_SPIN.LK_CUSTOMER_TYPE where LK_CUSTOMER_TYPE.CUSTOMER_TYPE_ID = CUSTOMER.CUSTOMER_TYPE_ID AND login_name = 'RETAILTESTPROD'

select * from MIT_SPIN.CUSTOMER, MIT_SPIN.LK_CUSTOMER_TYPE where LK_CUSTOMER_TYPE.CUSTOMER_TYPE_ID = CUSTOMER.CUSTOMER_TYPE_ID AND login_name = 'TESTNETANT6'

select *
from    MIT_MITEC2.sales_order so,
        MIT_MITEC2.sales_order_party sop,
        MIT_MITEC2.mit_user mu,
        MIT_SPIN.customer c,
        mit_spin.address a,
        mit_mitec2.comm_channel cc,
        mit_mitec2.lk_comm_channel lk
-- where   so.creation_date > to_date('07-03-2012', 'DD-MM-yyyy')
where so.creation_date > to_date('2012-03-16 20:00:00', 'YYYY-MM-DD HH24:MI:SS')
        and so.order_status_id in (60, 70, 40)
        and so.sales_order_id = sop.sales_order_id
        and sop.party_role = 50
        and sop.party_id = mu.party_id
        and mu.login = c.login_name
        and c.address_id = a.address_id
        and mu.party_id = cc.party_id
        and cc.comm_channel_id = lk.comm_channel_id




select * from MIT_SPIN.CUSTOMER where customer_id = 545461

        select * 
                from 
                        MIT_MITEC2.sales_order so,
                        MIT_MITEC2.sales_order_party sop,
                        MIT_MITEC2.party p,
                        MIT_SPIN.CUSTOMER c
                where 
                        so.creation_date > to_date('07-mar-2012') 
                        and so.order_status_id in (60, 70, 40) 
                        and so.sales_order_id = sop.sales_order_id
                        
select * 
        from 
                MIT_MITEC2.sales_order so,
                MIT_MITEC2.sales_order_party sop
--                MIT_MITEC2.party p
--                MIT_SPIN.CUSTOMER c
        where 
                so.creation_date > to_date('07-mar-2012') 
                and so.order_status_id in (60, 70, 40) 
                and so.sales_order_id = sop.sales_order_id
                and sop.sales_order_party_id = p.party_id
                and p.spin_customer_id = c.customer_id

select * from MIT_MITEC2.party where party.party_id = 3622628

select * FROM MIT_SPIN.CUSTOMER where CUSTOMER.customer_id = 69135

3622628
3622627
3622631
3622630
3622640
3622645

51166
2846388
51166
2844966
51166
2849162

select SOURCEIP from MIT_MITEC2.sales_order WHERE creation_date > to_date('07-mar-2012')  and order_status_id in (60, 70, 40)

select * from MIT_MITEC2.sales_order, MIT_MITEC2.sales_order_party  where sales_order.sales_order_id = sales_order_party.sales_order_id and creation_date > to_date('06-mar-2012')  and order_status_id in (60, 70, 40)

select  * from MIT_MITEC2.sales_order_party where sales_order_party_id = 3618060

select * from MIT_MITEC2.party where party_id = 51166

select * from MIT_SPIN.CUSTOMER where customer_id = 69135



select * from MIT_SPIN.CUSTOMER c, MIT_MITEC2.sales_order_party sop, MIT_MITEC2.party p where c.customer_id = p.spin_customer_id and sop.sales_order_party_id = p.party_id and sop.sales_order_party_id = 3618060

select * from MIT_MITEC2.sales_order_party sop, MIT_MITEC2.party p where  sop.sales_order_party_id = p.party_id and sop.sales_order_party_id = 3618060