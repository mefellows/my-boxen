select * from MIT_SPIN.CUSTOMER where last_login_date > to_date(1-jan-2008)

select count(customer_id) from MIT_SPIN.CUSTOMER where last_login_date > to_date('1-jan-2012')

select count(distinct(lower(password))) from MIT_SPIN.CUSTOMER where last_login_date > to_date('1-jan-2012')



select count(customer_id) from MIT_SPIN.CUSTOMER where lower(password) like 'bob%' and last_login_date > to_date('1-jan-2012')

select * from MIT_SPIN.CUSTOMER where lower(password) like 'pass%' and last_login_date > to_date('1-jan-2012')

select * from MIT_SPIN.CUSTOMER where lower(password) in (
'password',
'123456',
'12345678',
'abc123',
'qwerty',
'monkey',
'letmein',
'dragon',
'111111',
'baseball',
'iloveyou',
'trustno1',
'1234567',
'sunshine',
'master',
'123123',
'welcome',
'shadow',
'ashley',
'football',
'jesus',
'michael',
'ninja',
'mustang',
'password1')

and last_login_date > to_date('1-jan-2012')

to_date('1-jan-2011') and order_status_id = 110

 
-- 1314481 active accounts 2008
-- 1237363 distinct passwords 2008

-- 918444 active from 2010
-- 871425 distinct passwords 2010

-- 313789 active in 2012
-- 294820 distinct