select * from MIT_MITEC2.sales_order WHERE creation_date > to_date('01-april-2012') AND creation_date < to_date('30-april-2012')  and order_status_id in (60, 70, 40)

select count(*) from MIT_MITEC2.sales_order WHERE creation_date > to_date('01-april-2012') AND creation_date < to_date('30-april-2012')  and comments = 'NOTE: Order is rejected by the FPU.'