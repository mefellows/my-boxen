select 'ZELERNA' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Millennium Pharmaceuticals')
