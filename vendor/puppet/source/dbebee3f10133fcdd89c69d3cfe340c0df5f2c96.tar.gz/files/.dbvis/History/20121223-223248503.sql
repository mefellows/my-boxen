select * from domain_name where domain_name in ('trailertracker.com.au', 
'completebodybalance.com.au', 
