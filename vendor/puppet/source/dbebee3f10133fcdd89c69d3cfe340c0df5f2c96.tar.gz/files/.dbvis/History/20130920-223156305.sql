select * from MIT_SPIN.CUSTOMER where LOGIN_NAME like 'NETANT%'
