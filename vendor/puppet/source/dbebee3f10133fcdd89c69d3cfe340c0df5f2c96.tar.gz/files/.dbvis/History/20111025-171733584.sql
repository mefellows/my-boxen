@export on;
@export set filename="/Users/sgeary/Desktop/results.csv" appendfile="true" format="CSV";

select '[YELLOW TAIL] ADVENTUROZ' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');
select '[YELLOW TAIL] BUBBLES' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');
select '[YELLOW TAIL] PINK BUBBLES' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');
select '[YELLOW TAIL] RED BUBBLES' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');
select '[YELLOW TAIL]' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');
select '[YT]' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Casella Wines%');