require 'spec_helper'

describe 'boxen_private' do
  context 'supported operating systems' do
    ['Debian', 'RedHat'].each do |osfamily|
      describe "boxen_private class without any parameters on #{osfamily}" do
        let(:params) {{ }}
        let(:facts) {{
          :osfamily => osfamily,
        }}

        it { should compile.with_all_deps }

        it { should contain_class('boxen_private::params') }
        it { should contain_class('boxen_private::install').that_comes_before('boxen_private::config') }
        it { should contain_class('boxen_private::config') }
        it { should contain_class('boxen_private::service').that_subscribes_to('boxen_private::config') }

        it { should contain_service('boxen_private') }
        it { should contain_package('boxen_private').with_ensure('present') }
      end
    end
  end

  context 'unsupported operating system' do
    describe 'boxen_private class without any parameters on Solaris/Nexenta' do
      let(:facts) {{
        :osfamily        => 'Solaris',
        :operatingsystem => 'Nexenta',
      }}

      it { expect { should contain_package('boxen_private') }.to raise_error(Puppet::Error, /Nexenta not supported/) }
    end
  end
end
