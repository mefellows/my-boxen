select 'ZDH DUO' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Saint-Gobain Abrasives%')
select 'ZEDACE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm Proprietary%')
select 'ZEDACE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm%')
select 'ZEDIPINE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm%')