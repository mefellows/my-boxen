select * from MIT_SPIN.CUSTOMER where institution in ("Cement Australia (Queensland) Pty Limited",
"Cement Australia (Queensland) Pty Ltd",
"Cement Australia Holdings Pty Ltd",
"Cement Australia Packaged Products Pty Limited",
"Cement Australia Pty Limited",
"Cement Australia Pty Ltd")