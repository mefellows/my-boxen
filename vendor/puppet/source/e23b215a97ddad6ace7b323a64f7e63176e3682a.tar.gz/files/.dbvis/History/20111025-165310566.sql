select 'ZERO TORQUE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Michell Meat%');
select 'ZERO2' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Commonwealth Scientific And Industrial Research Organisation%');
select 'ZETEZE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Schering-Plough');
select 'ZETRON' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm%');
select 'ZEUS' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Strathfield Group%');