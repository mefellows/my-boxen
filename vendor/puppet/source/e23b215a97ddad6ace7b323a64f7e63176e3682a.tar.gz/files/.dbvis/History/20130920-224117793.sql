select * from MIT_MITEC2.SALES_ORDER order by creation_date desc

-- IWS Sales orders

select * from (select * from MIT_IWS.SALES_ORDER where CREATION_DATE is not null order by creation_date desc) where rownum < 50

select * from MIT_IWS.ORDER_LINE where service_desc ='rdtest20110412pmkn07.com'

-- IWS Provision requestse
select * from (select * from MIT_PPS.PROVISION_REQUEST order by REQUEST_DATE) where rownum < 20

select * from MIT_PPS.PROVISION_REQUEST_HISTORY where REQUEST_ID = '10422'


--
-- OM
--

select * from MIT_MITEC2.sales_order where sales_order_id = 57800




--
-- SPIN
--

select * from RESELLERS where RESELLER_CODE = 'HYPOST'

select * from RESELLERS where CLIENT_ID = 10


-- Get domain names for a particular account
select * from DOMAIN_NAME, RESELLERS, APPLICATION where RESELLERS.RESELLER_CODE = 'DBS4SPIN' AND APPLICATION.RESELLER_CLIENT_ID = RESELLERS.CLIENT_ID AND DOMAIN_NAME.APPLICATION_ID = APPLICATION.APPLICATION_ID


select * from DOMAIN_NAME where domain_name like 'wisdomcentre.com.au'

