select *
from    MIT_MITEC2.sales_order so,
        MIT_MITEC2.sales_order_party sop,
        MIT_MITEC2.mit_user mu,
        MIT_SPIN.customer c,
        mit_spin.address a,
        mit_mitec2.comm_channel cc,
        mit_mitec2.lk_comm_channel lk
-- where   so.creation_date > to_date('07-03-2012', 'DD-MM-yyyy')
where so.creation_date > to_date('2012-03-16 20:00:00', 'YYYY-MM-DD HH24:MI:SS')
        and so.order_status_id in (60, 70, 40)
        and so.sales_order_id = sop.sales_order_id
        and sop.party_role = 50
        and sop.party_id = mu.party_id
        and mu.login = c.login_name
        and c.address_id = a.address_id
        and mu.party_id = cc.party_id
        and cc.comm_channel_id = lk.comm_channel_id