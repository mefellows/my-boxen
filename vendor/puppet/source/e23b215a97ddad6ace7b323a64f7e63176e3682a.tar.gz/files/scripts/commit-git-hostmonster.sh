#!/bin/bash
echo "Pushing local $1 Git repository to remote at onegeek.com.au";

if [ "$1" = "" ]; then
	echo "Please enter a repository name (i.e. aes, onegeek, completebodybalance)"
	exit 1;
fi

git push ssh://onegeekd@www.onegeek.com.au/home/onegeekd/repository/$1.git --receive-pack=/home/onegeekd/git/bin/git-receive-pack master:master
