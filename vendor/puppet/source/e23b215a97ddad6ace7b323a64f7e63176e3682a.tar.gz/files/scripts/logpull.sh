#!/bin/bash


SERVERS=(prd-rtl-305 prd-rtl-306 prd-rtl-307 prd-rtl-308)


for server in ${SERVERS[@]}; do
	#mkdir $server
	#scp spinlogs@$server:/var/log/apache2/www.webcentral.com.au-2013-12-01.log $server/
	#scp spinlogs@$server:/var/log/apache2/www.webcentral.com.au-2013-11-30.log $server/
	scp spinlogs@$server:/var/log/apache2/monthly/201311-webcentral.com.au-access_log $server/
	scp spinlogs@$server:/var/log/apache2/monthly/201312-webcentral.com.au-access_log $server/
done 
