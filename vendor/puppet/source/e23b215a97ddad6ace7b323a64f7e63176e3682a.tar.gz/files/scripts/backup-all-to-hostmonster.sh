#!/bin/bash


# Music
#rsync -avzu -e "ssh -l onegeekd" -C -c  /Users/mattfellows/Music/iTunes/iTunes\ Music/ onegeekd@onegeek.com.au:backups/personal/music

# iPhot photos
rsync -avzu -e "ssh -l www" -C -c  \
 --exclude=AlbumData.xml \
 --exclude=Auto \
 --exclude=Contents \
 --exclude=Data \
 --exclude=Library.data \
 --exclude=Library.iPhoto \
 --exclude=Library6.iPhoto \
 --exclude=ThemeCache \
 --exclude=Thumb32Segment.data \
 --exclude=Thumb64Segment.data \
 --exclude=ThumbJPGSegment.data \
 --exclude=iPhoto.ipspot \
 --exclude=iPhotoLock.data \
 --exclude=iPod \
 --exclude=*.ithmb \
 /users/mfellows/Pictures/iPhoto\ Library/ www@onegeek.com.au:/storage/repository/personal/photos/iPhotoLibrary
