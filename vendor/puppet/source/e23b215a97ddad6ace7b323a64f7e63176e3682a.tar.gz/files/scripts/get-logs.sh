#!/bin/bash
SERVERS="prd-rtl-105 prt-rtl-106 prd-rtl-107 prd-rtl-108"
FILENAME=cocoon-log-2010_05_2

rm ~/logs1.txt
for server in $SERVERS
do
        mkdir -p ~/Desktop/$server
        echo "scp /var/prod/tomcat5/$server/$FILENAME*"
        scp spinlogs@bss.us.mit:/var/prod/tomcat5/$server/$FILENAME* ~/Desktop/$server/
done
