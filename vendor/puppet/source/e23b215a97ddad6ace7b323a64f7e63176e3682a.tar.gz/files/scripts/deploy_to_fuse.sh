#!/bin/bash

# Restart the server and wait for it to come back up...
#ssh deploy@dev1.substantiate.com.au "/home/deploy/deploy_to_fuse.sh restart"

ECHO="/bin/echo"
SLEEP="/bin/sleep"
SUDO="/usr/bin/sudo"

function check_port {
	nc -z dev1.substantiate.com.au 9100
}

        ${ECHO} "Waiting for startup..."
        COUNT=0
        MSG="Successful"
	
        #while [ "$( nc -z dev1.substantiate.com.au 9100 )" -ne "0 ]; do
	check_port
	PORT=$?
        LIM=30
        SLEEP_DURATION=20
                        (( DURATION = SLEEP_DURATION * LIM ))
echo $DURATION
        while [ "$PORT" != "0" ]; do
                ${SLEEP} ${SLEEP_DURATION}
                (( COUNT = COUNT + 1 ))
                if [ "${COUNT}" -eq "${LIM}" ]; then
                        ${ECHO}
			DURATION=0
                        MSG="Failed: Fuse not started in ${DURATION} minutes"
			echo "Startup: $MSG"
			exit 1
                else
                        ${ECHO} "." 
        		check_port
        		PORT=$?
                fi  
        done
        ${ECHO} "Startup: ${MSG}"
        ${ECHO} "Done!"
	exit 0
