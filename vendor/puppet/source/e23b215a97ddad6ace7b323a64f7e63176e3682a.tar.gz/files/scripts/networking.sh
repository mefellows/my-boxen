#!/bin/bash

echo "Stopping interface en1..."
sudo ifconfig en1 down

echo "Bringing up network interface en1..."
sudo ifconfig en1 up 

