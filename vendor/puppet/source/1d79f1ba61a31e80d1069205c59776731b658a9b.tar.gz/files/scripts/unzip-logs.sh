#!/bin/bash
SERVERS="prd-rtl-105 prt-rtl-106 prd-rtl-107 prd-rtl-108"
FILENAME=cocoon-log-2010_05_2

for server in $SERVERS
do
        echo "cd ~/Desktop/$server/"
        cd ~/Desktop/$server/
       
        echo "bzip2 -d *.bz2"
        bzip2 -d *.bz2
done
