select * from domain_name d, resellers r,application a where r.reseller_code = 'test' and a.reseller_client_id = r.client_id
and a.application_id = d.application_id and d.domain_name like '%.com' order by expiry_date desc;

select * from domain_name d where d.domain_name = 'cihansezer.com' 