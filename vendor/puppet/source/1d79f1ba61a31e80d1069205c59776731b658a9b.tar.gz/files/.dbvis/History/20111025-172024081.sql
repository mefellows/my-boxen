@export on;
@export set filename="/Users/sgeary/Desktop/results.csv" appendfile="true" format="CSV";
@continue on error;
@continue on warning;

select 'YOU ARE THE CENTRE OF OUR WORLD' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Millennium & Copthorne International%');
select 'YOU'LL NEVER SEE ANYTHING LIKE IT!' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Royal Agricultural Society of NSW%');
select 'YOUNG & RUBICAM' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Young & Rubicam Brands%');
select 'ZERO CARD ; ZEROCARD' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Bank of Western Australia%');
