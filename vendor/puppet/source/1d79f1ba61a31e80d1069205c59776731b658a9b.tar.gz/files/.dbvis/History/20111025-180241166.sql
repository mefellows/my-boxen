select '0 ZERO TORQUE' as trademark, INSTITUTION, LOGIN_NAME, TITLE, GIVEN_NAME, SURNAME, PHONE, ALT_PHONE, MOBILE, EMAIL from mit_spin.customer where upper(institution) like upper( 'Michell%');
