select "trademark name", * from MIT_SPIN.CUSTOMER where institution like '%B
undaberg%';