@export on
@export set filename="/Users/sgeary/Desktop/results.csv" format="csv";

select 'ZERO CARD ; ZEROCARD' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Bank of Western Australia%');
select 'ZERO CHANGE BATTERY' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Century Yuasa Batteries%');
select 'ZERO TORQUE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Michell Meat%');
select 'ZERO2' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Commonwealth Scientific And Industrial Research Organisation%');
select 'ZETEZE' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Schering-Plough%');
select 'ZETRON' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm%');
select 'ZEUS' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Strathfield Group%');
select 'ZEXOFEN' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Alphapharm%');
select 'ZIBEAUTIFUL' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Brown Brothers Milawa Vineyard%');
select 'ZIBUBBLY' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Brown Brothers Milawa Vineyard%');
select 'ZIENT' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Schering-Plough%');
select 'ZIFIZZ' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Brown Brothers Milawa Vineyard%');
select 'ZIFUN' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Brown Brothers Milawa Vineyard%');
select 'ZILAPEN' as trademark, institution from mit_spin.customer where upper(institution) like upper( 'Schering-Plough%');

@export off